define("dijit/form/nls/eu/Textarea", {      
//begin v1.x content
// used by both the editor and textarea widgets to provide information to screen reader users
	iframeEditTitle: 'editatu area',  // primary title for editable IFRAME, for screen readers when focus is in the editing area
	iframeFocusTitle: 'editatu arearen markoa'  // secondary title for editable IFRAME when focus is on outer container
									 //  to let user know that focus has moved out of editing area and to the
									 //  parent element of the editing area
//end v1.x content
});

