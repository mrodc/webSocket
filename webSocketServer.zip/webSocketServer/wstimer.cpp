#include "wstimer.h"

WsTimer::WsTimer(QWebSocket *tSocket, QObject *parent)
    : QObject{parent}
{
    // create a timer
    timer = new QTimer(this);
    pSocket = tSocket;
    // setup signal and slot
    connect(timer, SIGNAL(timeout()),
            this, SLOT(timerSlot()));

    // msec
    timer->start(1000);
}

void WsTimer::stop()
{
    timer->stop();
}

void WsTimer::timerSlot()
{
    QJsonObject json;

    QDateTime current = QDateTime::currentDateTime();

    auto dt = current.toLocalTime().toString("yyyy-MM-dd hh:mm:ss");

    json.insert("action","dateTime");
    json.insert("data", dt);

    QJsonDocument doc;
    doc.setObject(json);

    string obj = doc.toJson().toStdString();

    qDebug() << dt ;
    if( pSocket->isValid() )
        pSocket->sendTextMessage(obj.data());
}
