#ifndef WSTHREAD_H
#define WSTHREAD_H
#include "wstimer.h"

#include <QObject>
#include <QThread>
#include "QtWebSockets/qwebsocketserver.h"
#include "QtWebSockets/qwebsocket.h"

class WsThread : public QThread
{
    Q_OBJECT
public:
    WsThread(QWebSocket *pSocket);
    void run();
    bool threadConnected;

    WsTimer *wsTimer;

private Q_SLOTS:

    void processTextMessage(QString message);

    void socketDisconnected();

    void timerSlot();

};

#endif // WSTHREAD_H
