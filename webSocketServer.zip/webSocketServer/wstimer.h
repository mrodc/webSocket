#ifndef WSTIMER_H
#define WSTIMER_H

#include "allHeaders.h"

#include <QDateTime>

#include <QObject>
#include <QDebug>
#include <QTimer>

#include <QWebSocket>
#include <QWebSocketServer>

QT_FORWARD_DECLARE_CLASS(QWebSocketServer)
QT_FORWARD_DECLARE_CLASS(QWebSocket)
class WsTimer : public QObject
{
    Q_OBJECT
public:
    explicit WsTimer(QWebSocket *tSocket, QObject *parent = nullptr);
    QTimer *timer;

    void stop();
    QWebSocket *pSocket;

public slots:
    void timerSlot();

};

#endif // WSTIMER_H
