#include "wsthread.h"


WsThread::WsThread(QWebSocket *pSocket)
{
    threadConnected = true;
    connect(pSocket, &QWebSocket::textMessageReceived, this, &WsThread::processTextMessage);
    connect(pSocket, &QWebSocket::disconnected, this, &WsThread::socketDisconnected);

    wsTimer = new WsTimer(pSocket);

}

void WsThread::run()
{
    int cnt = 0;
    while(threadConnected){
        cnt++;
    }
}

void WsThread::processTextMessage(QString message)
{
    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
    auto port = pClient->peerPort();

        qDebug() << "Message received:" << message;
    if (pClient) {
        pClient->sendTextMessage(message);
    }
}

void WsThread::socketDisconnected()
{
    threadConnected = false;
    wsTimer->stop();

    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());


        qDebug() << "socketDisconnected:" << pClient;
    if (pClient) {

        pClient->deleteLater();
    }
    this->terminate();
}

void WsThread::timerSlot()
{

}
