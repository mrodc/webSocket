#ifndef BOUNCING_H
#define BOUNCING_H

#include "allHeaders.h"

class Bouncing
{
public:
    Bouncing();

    float v0 ;
    float theta;
    float g ;

    float x_0;
    float y_0;

    float dt;

    tuple<float, float> simulation(float xi, float t, float e);

    tuple<bool, float, float> ball(float xi, float t, float e);

    tuple<std::vector<float> , std::vector<float>> simulation();

};
#endif // BOUNCING_H
