#include "bouncing.h"


Bouncing::Bouncing() {

    v0 = 30.0;
    theta = 70.0 * M_PI / 180.0;
    g = 9.81;

    x_0 = 0.0;
    y_0 = 0.0;

    dt = 0.01;
}

tuple<float, float> Bouncing::simulation(float xi, float t, float e)
{
    auto x = [=](float xi, float t)
    {
        return xi + x_0 + v0 * cos(theta) * t;
    };

    auto y = [=](float t, float e)
    {
        return y_0 + v0 * e * sin(theta) * t - 0.5 * g * t * t;
    };

    return make_tuple(x(xi, t), y(t, e));

}

tuple<bool, float, float> Bouncing::ball(float xi, float t, float e)
{
    auto f = simulation(xi, t, e);
    if (get<1>(f) >= 0.0)
    {

        return make_tuple(true, get<0>(f), get<1>(f));
    }
    return make_tuple(false, get<0>(f), get<1>(f));
}

tuple<vector<float>, vector<float> > Bouncing::simulation()
{
    vector<float> x;
    vector<float> y;

    float xi = 0.0;
    int N = 0;

    while (N < 5)
    {
        float t = 0.0;

        while (t < 10.0)
        // for (; t < 10; t = t + dt)
        {
            auto e = 1.0 / (N + 2.0);
            auto sim = ball(xi, t, e);

            if (get<2>(sim) >= 0)
            {
                x.push_back(get<1>(sim));
                y.push_back(get<2>(sim));
            }
            t = t + dt;
            if (get<0>(sim) == false)
            {

                N += 1;
                xi = get<1>(sim);
                t = 100.0;
            }
        }
    }
    return make_tuple(x,y);
}
