#include "echoserver.h"


#include "QtWebSockets/qwebsocketserver.h"
#include "QtWebSockets/qwebsocket.h"
#include <QtCore/QDebug>

QT_USE_NAMESPACE

//EchoServer::EchoServer() {}

EchoServer::EchoServer(quint16 port, bool debug, QObject *parent) :
    QObject(parent),
    m_pWebSocketServer(new QWebSocketServer(QStringLiteral("Echo Server"),
                                            QWebSocketServer::NonSecureMode, this)),
    m_debug(debug)
{
    if (m_pWebSocketServer->listen(QHostAddress::Any, port)) {
        if (m_debug)
            qDebug() << "Echoserver listening on port" << port;
        connect(m_pWebSocketServer, &QWebSocketServer::newConnection,
                this, &EchoServer::onNewConnection);
        connect(m_pWebSocketServer, &QWebSocketServer::closed, this, &EchoServer::closed);

        // timer = new QChronoTimer(this);
        // connect(timer, &QChronoTimer::timeout, this, &EchoServer::processTimer);

        // std::chrono::nanoseconds nsec(1000000000);


        // timer->setInterval(nsec);
        // timer->start();
    }
}

EchoServer::~EchoServer()
{
    m_pWebSocketServer->close();
    qDeleteAll(m_clients.begin(), m_clients.end());
}

void EchoServer::onNewConnection()
{
    QWebSocket *pSocket = m_pWebSocketServer->nextPendingConnection();


    // connect(pSocket, &QWebSocket::textMessageReceived, this, &EchoServer::processTextMessage);
    // connect(pSocket, &QWebSocket::binaryMessageReceived, this, &EchoServer::processBinaryMessage);
    // connect(pSocket, &QWebSocket::disconnected, this, &EchoServer::socketDisconnected);


    // auto peerAdd = pSocket->peerAddress();
    // auto peerName = pSocket->peerName();
    // auto peerPort = pSocket->peerPort();

    // timer = new QChronoTimer(this);
    // connect(timer, &QChronoTimer::timeout, this, &EchoServer::processTimer);

    // std::chrono::nanoseconds nsec(1000000000);


    // timer->setInterval(nsec);
    // timer->start();

    //m_clients << pSocket;

    WsThread *wsThread = new WsThread(pSocket);
    //m_threads << wsThread;

    wsThread->start();

    // pSocket->sendTextMessage("Super Connected");

}

void EchoServer::processTextMessage(QString message)
{

    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
    auto port = pClient->peerPort();
    if (m_debug)
        qDebug() << "Message received:" << message;
    if (pClient) {
        pClient->sendTextMessage(message);
    }
}

void EchoServer::processBinaryMessage(QByteArray message)
{
    pClient = qobject_cast<QWebSocket *>(sender());
    if (m_debug)
        qDebug() << "Binary Message received:" << message;
    if (pClient) {
        pClient->sendBinaryMessage(message);
    }
}

void EchoServer::socketDisconnected()
{
    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
    if (m_debug)
        qDebug() << "socketDisconnected:" << pClient;
    if (pClient) {
        m_clients.removeAll(pClient);
        pClient->deleteLater();
    }
    timer->stop();
}

void EchoServer::processTimer()
{
    QDateTime current = QDateTime::currentDateTime();

    auto dt = current.toLocalTime().toString("yyyy-MM-dd hh:mm:ss");
    qDebug() << dt ;
    m_clients[0]->sendTextMessage(dt);
    //pClient->sendTextMessage(dt);
}
