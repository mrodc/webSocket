#ifndef ALLHEADERS_H
#define ALLHEADERS_H
#include <iostream>
#include <tuple>
#include <vector>
#include <math.h>
#include <cmath>

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

#include <QJsonParseError>
#include <QJsonValue>
//#define M_PI 3.14159265358979323846

using namespace std;

#endif // ALLHEADERS_H
