#ifndef ECHOSERVER_H
#define ECHOSERVER_H
#include "wsthread.h"

#include <QObject>
#include <QList>
#include <QByteArray>
#include <QChronoTimer>
#include <QDateTime>

QT_FORWARD_DECLARE_CLASS(QWebSocketServer)
QT_FORWARD_DECLARE_CLASS(QWebSocket)

class EchoServer  : public QObject
{
     Q_OBJECT

public:
     explicit EchoServer(quint16 port, bool debug = true, QObject *parent = nullptr);
     ~EchoServer();

     QChronoTimer *timer;
     QWebSocket *pClient;


 Q_SIGNALS:
     void closed();

 private Q_SLOTS:
     void onNewConnection();
     void processTextMessage(QString message);
     void processBinaryMessage(QByteArray message);
     void socketDisconnected();

     void processTimer();

 private:
     QWebSocketServer *m_pWebSocketServer;
     QList<QWebSocket *> m_clients;
     QList<WsThread *> m_threads;
     bool m_debug;
};

#endif // ECHOSERVER_H
