#include "wsfunction.h"

WsFunction::WsFunction() {
    wsFunction.insert({"plotBouncing", &WsFunction::plotBouncing});
    //execFunction("QString message");
}

// string WsFunction::execFunction(QString name)
// {

// }
//{"function":"plotBouncing"}
QString WsFunction::execFunction(QString message)
{
    QString status = "NoData";
    auto jsonDoc = QJsonDocument::fromJson(message.toUtf8());
    QJsonObject error;
    QJsonDocument eDoc;

    if( jsonDoc.isEmpty()){

        error.insert("action","error");
        error.insert("data", "noData");

        eDoc.setObject(error);

        status = eDoc.toJson();
        return status;
    }


    QString cmd = "none";
    QString function = jsonDoc["function"].toString();//.data();
    auto msg = jsonDoc["message"];
    if( !msg.isUndefined())
        cmd = msg.toString();

    WsFunction::wsFunc ptr =0;
    auto p = wsFunction.find(function);
    if( p != wsFunction.end()){
        ptr = p->second;
        auto jsnObj = (this->*ptr)(cmd);

        jsnObj.insert("action", function);
        QJsonDocument doc;
        doc.setObject(jsnObj);

        status = doc.toJson();
        string obj = status.toStdString();

        //cout << endl << obj << endl;
        //int size = obj.size();

    }
    else{

        error.insert("action","error");
        error.insert("data", "unKown Function: " + function);

        eDoc.setObject(error);

        status = eDoc.toJson();

    }

    return status;
}

QJsonObject WsFunction::plotBouncing(QString value)
{
        Bouncing bnc;
        auto data = bnc.simulation();

        auto x = get<0>(data);
        auto y = get<1>(data);


        QJsonObject json;
        QJsonArray points;
        int size = x.size();
        for(int i=0; i< size; i++){
            auto z = ( y[i])+ 10;
            QJsonObject _3dPoint;
            _3dPoint.insert("x",roundTo(x[i]));
            _3dPoint.insert("y", roundTo(y[i]));
            _3dPoint.insert("z", roundTo(z));

            points.append(_3dPoint);
        }

        json.insert("data", points);


        return json;
}

double WsFunction::roundTo(double value, int places) {
    double rndV = 10.0*places;
    return std::round(value * rndV) / rndV;
}
