#ifndef WSFUNCTION_H
#define WSFUNCTION_H

#include "allHeaders.h"

#include "bouncing.h"


class WsFunction
{
public:
    WsFunction();
public:
    typedef QJsonObject (WsFunction::*wsFunc)(QString);

    QString execFunction(QString name);


    double roundTo(double value, int places = 2);
private:
    QJsonObject plotBouncing(QString value);
    map<QString, wsFunc> wsFunction;

};

#endif // WSFUNCTION_H
